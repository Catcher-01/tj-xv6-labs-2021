#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
#include "kernel/fs.h"
void find(char *path, char *target) {
    int fd;
    struct dirent de;
    struct stat st;
    if ((fd = open(path, 0)) < 0) return;
    if (fstat(fd, &st) < 0) { close(fd); return; }
    if (st.type != T_DIR) { close(fd); return; }
    while (read(fd, &de, sizeof(de)) == sizeof(de)) {
        if (de.inum == 0) continue;
        char buf[512], *p;
        if (strcmp(de.name, ".") == 0 || strcmp(de.name, "..") == 0) continue;
        strcpy(buf, path);
        p = buf + strlen(buf);
        *p++ = '/'; strcpy(p, de.name);
        if (stat(buf, &st) < 0) continue;
        if (st.type == T_FILE && strcmp(de.name, target) == 0)
            printf("%s\n", buf);
        if (st.type == T_DIR)
            find(buf, target);
    }
    close(fd);
}
int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(2, "usage: find <path> <filename>\n");
        exit(1);
    }
    find(argv[1], argv[2]);
    exit(0);
}